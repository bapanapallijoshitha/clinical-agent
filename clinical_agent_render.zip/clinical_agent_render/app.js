const $ = (id) => document.getElementById(id);
let demo = null;

async function loadDemo() {
  const r = await fetch('/api/demo-data');
  demo = await r.json();
  $('patientId').textContent = demo.patient_id;
  $('visitDate').textContent = demo.visit_date;
  $('transcript').innerHTML = demo.turns.map(t => `<div class="turn ${t.speaker}"><div class="speaker">${t.speaker.toUpperCase()}</div><p>${escapeHtml(t.text)}</p></div>`).join('');
  $('lateText').textContent = demo.late_update?.text || '';
}

function escapeHtml(s) { return String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function clearTrace(){ $('trace').innerHTML=''; }
function addTrace(e, i) {
  const time = new Date().toLocaleTimeString([], {hour12:false});
  const icon = e.type === 'validation' ? (e.status === 'PASS' ? '✓' : '⚠') : e.type === 'tool' ? '↳' : e.type === 'revision' ? '↻' : e.type === 'adapt' ? '◆' : '•';
  const cls = e.type === 'validation' && e.status !== 'PASS' ? 'fail' : e.type === 'validation' ? 'validation' : '';
  $('trace').insertAdjacentHTML('beforeend', `<div class="trace-item ${cls}"><div class="trace-time">${time}</div><div class="trace-icon">${icon}</div><div class="trace-message">${escapeHtml(e.message)}${e.tool ? `<small>${escapeHtml(e.tool)}</small>` : ''}</div></div>`);
  $('trace').scrollTop = $('trace').scrollHeight;
}

function renderRecord(o) {
  const r = o.record || {};
  const obj = r.objective || {};
  const metrics = Object.entries(obj).map(([k,v]) => `<div class="metric"><b>${escapeHtml(v)}</b><small>${escapeHtml(k)}</small></div>`).join('');
  $('record').innerHTML = `
    <div class="record-block"><h3>SUBJECTIVE</h3><p>${escapeHtml(r.subjective || '—')}</p></div>
    <div class="record-block"><h3>OBJECTIVE</h3><div class="objective">${metrics || '<span>—</span>'}</div></div>
    <div class="record-block"><h3>STATUS SUMMARY</h3><p>${escapeHtml(r.status_summary || '—')}</p></div>
    <div class="record-block"><h3>PLAN / ACTIONS FOR REVIEW</h3><ul>${(r.plan_actions || []).map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul></div>
    <div class="record-block"><h3>UNRESOLVED FOR CLINICIAN REVIEW</h3><ul>${(o.unresolved_for_clinician_review || []).map(x=>`<li><b>${escapeHtml(x.issue)}</b> — ${escapeHtml(x.detail)}</li>`).join('') || '<li>None</li>'}</ul></div>`;
  const v=o.validation||{}; $('validationBadge').textContent=v.status||'UNKNOWN'; $('validationBadge').className='validation '+(v.status==='FAIL'?'fail':'');
  if(v.issues?.length){ $('issues').classList.remove('hidden'); $('issues').innerHTML='<strong>Validation findings</strong><ul>'+v.issues.map(x=>`<li>${escapeHtml(x.detail)}</li>`).join('')+'</ul>'; } else $('issues').classList.add('hidden');
}

async function runAgent(){
  $('runBtn').disabled=true; $('updateBtn').disabled=true; $('systemStatus').textContent='AGENT RUNNING'; $('traceState').textContent='LIVE'; clearTrace(); $('record').innerHTML='<div class="empty">Agent is gathering and validating...</div>'; $('validationBadge').textContent='RUNNING'; $('validationBadge').className='validation neutral'; $('updateSection').classList.add('hidden');
  try{
    const r=await fetch('/api/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({demo:true})});
    const data=await r.json(); if(!r.ok) throw new Error(data.detail||'Agent failed');
    data.events.forEach((e,i)=>setTimeout(()=>addTrace(e,i), i*130));
    setTimeout(()=>renderRecord(data.output), data.events.length*130+100);
    setTimeout(()=>{ $('systemStatus').textContent='AGENT COMPLETE'; $('traceState').textContent='COMPLETE'; $('updateBtn').disabled=false; $('updateSection').classList.remove('hidden'); }, data.events.length*130+250);
  }catch(e){$('trace').innerHTML=`<div class="empty">${escapeHtml(e.message)}</div>`;$('systemStatus').textContent='ERROR';}
  finally{setTimeout(()=>{$('runBtn').disabled=false},800)}
}

async function adapt(){
  $('updateBtn').disabled=true; $('systemStatus').textContent='ADAPTING'; $('adaptStatus').textContent='PROCESSING';
  try{
    const r=await fetch('/api/adapt',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:demo.late_update.text})});
    const data=await r.json(); if(!r.ok) throw new Error(data.detail||'Adaptation failed');
    data.events.forEach((e,i)=>setTimeout(()=>addTrace(e,i), i*130));
    setTimeout(()=>{renderRecord(data.output);$('adaptStatus').textContent='UPDATED';$('systemStatus').textContent='RECORD ADAPTED';$('traceState').textContent='ADAPTED'}, data.events.length*130+150);
  }catch(e){$('adaptStatus').textContent='ERROR';$('systemStatus').textContent='ERROR';alert(e.message)}
  finally{setTimeout(()=>{$('updateBtn').disabled=false},1200)}
}

$('runBtn').addEventListener('click',runAgent); $('updateBtn').addEventListener('click',adapt); loadDemo().catch(console.error);
