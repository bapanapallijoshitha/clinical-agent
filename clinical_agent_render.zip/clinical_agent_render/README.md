# Clinical Agent — Render Deployment

Autonomous Clinical Documentation & Follow-up Agent demo.

## Run locally

```bash
pip install -r requirements.txt
set GROQ_API_KEY=your_key_here
uvicorn main:app --host 0.0.0.0 --port 8000
```

Open http://localhost:8000

## Render

- Runtime: Python 3
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Environment variable: `GROQ_API_KEY`

The project uses synthetic patient data for demonstration.
