import json
import os
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from orchestrator import Orchestrator

ROOT_DIR = Path(__file__).resolve().parent
DATA_DIR = ROOT_DIR / "data"

app = FastAPI(title="Clinical Agent", version="1.0.0")
app.mount("/static", StaticFiles(directory=ROOT_DIR), name="static")

class AdaptRequest(BaseModel):
    text: str


def load_transcript():
    with open(DATA_DIR / "transcript.json", encoding="utf-8") as f:
        return json.load(f)


def clean_output(record_obj):
    validation = record_obj.get("_validation", {"status": "UNKNOWN", "issues": []})
    return {
        "patient_id": record_obj.get("patient_id"),
        "visit_date": record_obj.get("visit_date"),
        "record": record_obj["record"],
        "unresolved_for_clinician_review": record_obj["unresolved_for_clinician_review"],
        "reasoning_log": record_obj["reasoning_log"],
        "validation": validation,
    }


@app.get("/")
def home():
    return FileResponse(ROOT_DIR / "index.html")


@app.get("/api/health")
def health():
    return {"status": "ok", "groq_configured": bool(os.environ.get("GROQ_API_KEY"))}


@app.get("/api/demo-data")
def demo_data():
    t = load_transcript()
    return {
        "patient_id": t["patient_id"],
        "visit_date": t["visit_date"],
        "turns": t["turns"],
        "late_update": t.get("late_update"),
    }


@app.post("/api/run")
def run_agent():
    if not os.environ.get("GROQ_API_KEY"):
        raise HTTPException(status_code=500, detail="GROQ_API_KEY is not configured in the Render environment variables.")
    try:
        transcript = load_transcript()
        events = []
        orch = Orchestrator(transcript["patient_id"], transcript, event_callback=events.append)
        result = orch.draft()
        output = clean_output({**result, "patient_id": transcript["patient_id"], "visit_date": transcript["visit_date"]})
        return {"phase": "draft", "output": output, "events": events, "late_update": transcript.get("late_update")}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Server error: {type(exc).__name__}: {exc}") from exc


@app.post("/api/adapt")
def adapt_agent(body: AdaptRequest):
    if not os.environ.get("GROQ_API_KEY"):
        raise HTTPException(status_code=500, detail="GROQ_API_KEY is not configured in the Render environment variables.")
    try:
        transcript = load_transcript()
        late_text = body.text or transcript.get("late_update", {}).get("text")
        if not late_text:
            raise HTTPException(status_code=400, detail="No late update supplied.")
        events = []
        orch = Orchestrator(transcript["patient_id"], transcript, event_callback=events.append)
        orch.draft()
        result = orch.adapt(late_text)
        output = clean_output({**result, "patient_id": transcript["patient_id"], "visit_date": transcript["visit_date"]})
        return {"phase": "adaptation", "output": output, "events": events, "late_update": {"text": late_text}}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Server error: {type(exc).__name__}: {exc}") from exc
