"""
Deterministic 'sandbox' tools the orchestrator agent can call.
Each function reads from the synthetic JSON records in data/ and returns
plain dicts (never free text) so results are unambiguous and easy to log.
"""
import json
import os

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


def _load(name):
    with open(os.path.join(DATA_DIR, name)) as f:
        return json.load(f)


def lookup_medication(name: str) -> dict:
    """Look up dosing/interaction-relevant info for a medication name."""
    meds = _load("medications.json")["active_medications"]
    match = next((m for m in meds if m["name"].lower() == name.lower()), None)
    known_interactions = {
        "lisinopril": ["Can raise serum potassium; monitor with potassium-sparing "
                       "diuretics or renal impairment."],
        "metformin": ["Renal clearance dependent; review dose if eGFR declines."],
    }
    return {
        "queried_name": name,
        "found_in_active_medications": match is not None,
        "record": match,
        "known_interaction_notes": known_interactions.get(name.lower(), []),
    }


def lookup_allergy(patient_id: str) -> dict:
    """Retrieve documented allergies for a patient."""
    data = _load("allergies.json")
    if data["patient_id"] != patient_id:
        return {"patient_id": patient_id, "documented_allergies": None,
                "error": "no record found for this patient_id"}
    return {"patient_id": patient_id, "documented_allergies": data["documented_allergies"]}


def get_labs(patient_id: str, panel: str = None) -> dict:
    """Retrieve lab panel results for a patient, optionally filtered by panel name."""
    data = _load("labs.json")
    if data["patient_id"] != patient_id:
        return {"patient_id": patient_id, "panels": [], "error": "no record found"}
    panels = data["panels"]
    if panel:
        panels = [p for p in panels if panel.lower() in p["panel"].lower()]
    return {"patient_id": patient_id, "panels": panels}


def guideline_rag_search(query: str) -> dict:
    """Very small keyword-overlap search over the local guideline corpus.
    Stands in for a real embedding-based RAG retriever."""
    corpus = _load("guidelines.json")
    q_terms = set(query.lower().replace(",", " ").replace("-", " ").split())
    scored = []
    for entry in corpus:
        kw = set(k.lower() for k in entry["keywords"])
        overlap = len(q_terms & kw) + sum(1 for k in kw if k in query.lower())
        if overlap > 0:
            scored.append((overlap, entry))
    scored.sort(key=lambda x: -x[0])
    top = [e for _, e in scored[:3]]
    return {"query": query, "results": top}


def get_prior_notes(patient_id: str) -> dict:
    data = _load("prior_notes.json")
    if data["patient_id"] != patient_id:
        return {"patient_id": patient_id, "notes": [], "error": "no record found"}
    return data


TOOL_FUNCTIONS = {
    "lookup_medication": lookup_medication,
    "lookup_allergy": lookup_allergy,
    "get_labs": get_labs,
    "guideline_rag_search": guideline_rag_search,
    "get_prior_notes": get_prior_notes,
}
